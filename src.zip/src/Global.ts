export var Global = {
  userId: "",
  addId: "",
  Rupees: "",
  //url: "http://52.23.253.202:5001/" //Localhost
 //url: "http://192.168.0.100:8080/" //Localhost
 url:'http://ec2-13-233-107-43.ap-south-1.compute.amazonaws.com:8080/'
};
